#pragma once

// Structure
struct temp_msg {
  double mv;
  double temp;
};

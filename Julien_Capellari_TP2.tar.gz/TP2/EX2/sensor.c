#include <math.h>
#include <stdio.h>

#include "contiki.h"

#include "dev/adc-zoul.h"
#include "dev/zoul-sensors.h"

#define B 4250
#define R0 100000

// Process
PROCESS(sensor_process, "Sensor");
AUTOSTART_PROCESSES(&sensor_process);

// Sensor ?
PROCESS_THREAD(sensor_process, ev, data) {
  static struct etimer et;

  PROCESS_BEGIN();

  adc_zoul.configure(SENSORS_HW_INIT, ZOUL_SENSORS_ADC_ALL);

  while (1) {
    etimer_set(&et, CLOCK_SECOND / 2);
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&et));

    int raw = adc_zoul.value(ZOUL_SENSORS_ADC1);
    double mv = raw / 10.0;
    double r = R0 * ((4095 / mv) - 1.0);
    double t = 1.0 / (log(r / R0) / B + 1 / 298.15) - 273.15;

    printf("ADC1 = %d raw  %d mv => %d °C\n", raw, (int) round(mv), (int) round(t));
  }

  PROCESS_END();
}
